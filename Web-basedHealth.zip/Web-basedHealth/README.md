ACCOUNT :D

admin
user: admin@admin.com
user: admin@edoc.com
pass: 123

doctor
user:dcJasper@kupal.com
pass:123

patient
user: goblin@gmail.com
pass: 123