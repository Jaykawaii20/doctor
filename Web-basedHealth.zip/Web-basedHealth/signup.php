<?php

@include 'connection.php';

if(isset($_POST['submit'])){

   $name = mysqli_real_escape_string($database, $_POST['name']);
   $email = mysqli_real_escape_string($database, $_POST['email']);
   $middlename = mysqli_real_escape_string($database, $_POST['middlename']);
   $lastname = mysqli_real_escape_string($database, $_POST['lastname']);
   $address = mysqli_real_escape_string($database, $_POST['address']);
   $Gender = mysqli_real_escape_string($database, $_POST['Gender']);
   $civil = mysqli_real_escape_string($database, $_POST['civil']);
   $age = mysqli_real_escape_string($database, $_POST['age']);
   $day = mysqli_real_escape_string($database, $_POST['day']);
   $month = mysqli_real_escape_string($database, $_POST['month']);
   $year = mysqli_real_escape_string($database, $_POST['year']);
   $pass = md5($_POST['password']);
   $cpass = md5($_POST['cpassword']);

   $select = " SELECT * FROM patient WHERE email = '$email' && password = '$pass' ";

   $result = mysqli_query($database, $select);

   if(mysqli_num_rows($result) > 0){

      $error[] = 'user already exist!';

   }else{

      if($pass != $cpass){
         $error[] = 'password not matched!';
      }else{
         $insert = "INSERT INTO patient(name, email, middlename, lastname, address, Gender, civil, age, day, month, year, password) VALUES('$name','$email','$middlename','$lastname','$address','$Gender','$civil','$age','$day','$month','$year','$pass')";
         mysqli_query($database, $insert);
         header('location:Login.php');
      }
   }

};


?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <link rel="icon" type="image/png" href="icon/icon.png">
   <title>Register form</title>

   <!-- custom css file link  -->
   <link rel="stylesheet" href="style.css">

</head>
<body>
   
<div class="form-container">

   <form action="" method="post">
      <h3>register now</h3>
      <?php
      if(isset($error)){
         foreach($error as $error){
            echo '<span class="error-msg">'.$error.'</span>';
         };
      };
      ?>
      <input type="text" name="name" required placeholder="Enter your name">
      <input type="email" name="email" required placeholder="Enter your email">
      <input type="text" name="middlename" required placeholder="Enter your middle name">
      <input type="text" name="lastname" required placeholder="Enter your last name">
      <input type="text" name="address" required placeholder="Enter your address">
      <select name="Gender">
        <option value="">Select your gender</option>
         <option value="Male">Male</option>
         <option value="Female">Female</option>
      </select>
      <select name="civil">
      <option value="">Select your civil status</option>
         <option value="single">single</option>
         <option value="married">married</option>
      </select>
      <h13>Select your birthday</h13>
      <select name="day">
         <option value="">Select day</option>
         <option value="1">1</option>
         <option value="2">2</option>
         <option value="3">3</option>
         <option value="4">4</option>
      </select>
      <select name="month">
         <option value="">Select month</option>
         <option value="january">january</option>
         <option value="february">february</option>
         <option value="march">march</option>
         <option value="april">april</option>
      </select>
      <select name="year">
         <option value="">Select year</option>
         <option value="1999">1999</option>
         <option value="2000">2000</option>
         <option value="2001">2001</option>
         <option value="2002">2002</option>
      </select>
      <input type="text" name="age" required placeholder="Enter your age">
      <input type="password" name="password" required placeholder="Enter your password">
      <input type="password" name="cpassword" required placeholder="Confirm your password">
      <input type="submit" name="submit" value="register now" class="form-btn">
      <p>already have an account? <a href="Login.php">login now</a></p>
   </form>

</div>

</body>
</html>