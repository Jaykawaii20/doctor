<?php

    $database= new mysqli("","root","","dbkupal");
    if ($database->connect_error){
        die("Connection failed:  ".$database->connect_error);
    }

?>