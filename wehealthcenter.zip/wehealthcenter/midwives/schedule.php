<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/animations.css">  
    <link rel="stylesheet" href="../css/main.css">  
    <link rel="stylesheet" href="../css/admin.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/5.10.2/main.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/fullcalendar@5.11.3/main.min.css" rel="stylesheet"/>
    <script src="https://cdn.jsdelivr.net/npm/fullcalendar@5.11.3/main.min.js"></script>
    <title>Schedule</title>
    <style>
        .popup{
            animation: transitionIn-Y-bottom 0.5s;
        }
        .sub-table{
            animation: transitionIn-Y-bottom 0.5s;
        }
                /* Calendar Styles */
                #calendar {
            max-width: 900px;
            margin: 20px auto;
            padding: 20px;
        }

        /* Form Styles */
        .event-form {
            margin: 20px auto;
            max-width: 400px;
            display: flex;
            flex-direction: column;
        }

        .event-form input,
        .event-form button {
            margin-bottom: 10px;
        }
</style>
</head>
<body>
                <?php

                // Start the session
                session_start();

                // Check if the user is logged in
                if (isset($_SESSION["user"])) {
                    if ($_SESSION["user"] == "" || $_SESSION['usertype'] != 'm') {  // Changed 'd' to 'm' for midwives
                        header("location: ../login.php");
                        exit();  // Always a good practice to exit after a redirect
                    } else {
                        $useremail = $_SESSION["user"];
                    }
                } else {
                    header("location: ../login.php");
                    exit();  // Always a good practice to exit after a redirect
                }

                // Import database
                include("../connection.php");

                // Query to get midwife details
                $userrow = $database->query("SELECT * FROM midwives WHERE email='$useremail'"); // Change table name to midwives
                if ($userrow) {  // Check if the query was successful
                    $userfetch = $userrow->fetch_assoc();
                    $userid = $userfetch["midwife_id"];  // Adjust to your actual field name for midwife ID
                    $username = $userfetch["fullname"];   // Adjust to your actual field name for midwife name
                } else {
                    // Handle the case where the query failed
                    header("location: ../login.php"); // Redirect if query fails
                    exit();  // Always a good practice to exit after a redirect
                }

                // Uncomment the line below for debugging
                // echo $userid;
                // Fetch appointments
// SQL query to fetch appointments where the appointment name is 'doctor' and the status is 'approved'
$sql = "SELECT * FROM appointment_patient WHERE appointmentname = 'midwives' AND status = 'approved'";
$result = $database->query($sql);

// Check for query execution errors
if (!$result) {
    die("Query failed: " . $database->error);
}

// Initialize appointments array
$appointments = [];
while ($row = $result->fetch_assoc()) {
    $appointments[] = [
        'title' => $row['appointmentname'] ?: 'appointment',  // Default title if none provided
        'start' => $row['date'],
        'name'  => $row['pid'],
        'id'    => $row['id']  // Use appointment ID for future edits
    ];
}

// Example output for debugging (optional)
// echo '<pre>'; print_r($appointments); echo '</pre>';


// Debugging: Check if appointments were fetched
if (empty($appointments)) {
    echo "<script>console.log('No appointments found.');</script>";
} else {
    echo "<script>console.log('Appointments fetched successfully: " . count($appointments) . "');</script>";
}
 //echo $userid;
                ?>

 <div class="container">
     <div class="menu">
     <table class="menu-container" border="0">
             <tr>
                 <td style="padding:10px" colspan="2">
                     <table border="0" class="profile-container">
                         <tr>
                             <td width="30%" style="padding-left:20px" >
                                 <img src="../img/user.png" alt="" width="100%" style="border-radius:50%">
                             </td>
                             <td style="padding:0px;margin:0px;">
                                 <p class="profile-title"><?php echo substr($username,0,13)  ?>..</p>
                                 <p class="profile-subtitle"><?php echo substr($useremail,0,22)  ?></p>
                             </td>
                         </tr>
                         <tr>
                             <td colspan="2">
                                 <a href="../logout.php" ><input type="button" value="Log out" class="logout-btn btn-primary-soft btn"></a>
                             </td>
                         </tr>
                 </table>
                 </td>
             </tr>
             <tr class="menu-row">
                    <td class="menu-btn menu-icon-appoinment">
                        <a href="appointment.php" class="non-style-link-menu"><div><p class="menu-text">My Appointments</p></a></div>
                    </td>
                </tr>
                
                <tr class="menu-row" >
                    <td class="menu-btn menu-icon-session">
                        <a href="schedule.php" class="non-style-link-menu"><div><p class="menu-text">My Sessions</p></div></a>
                    </td>
                </tr>
                <tr class="menu-row" >
                    <td class="menu-btn menu-icon-settings">
                        <a href="settings.php" class="non-style-link-menu"><div><p class="menu-text">Settings</p></a></div>
                    </td>
                </tr>
        
             
         </table>
        </div>
        <div class="dash-body">
            <table border="0" width="100%" style=" border-spacing: 0;margin:0;padding:0;margin-top:25px; ">
                <tr >
                    <td width="13%" >
                    <a href="schedule.php" ><button  class="login-btn btn-primary-soft btn btn-icon-back"  style="padding-top:11px;padding-bottom:11px;margin-left:20px;width:125px"><font class="tn-in-text">Back</font></button></a>
                    </td>
                    <td>
                        <p style="font-size: 23px;padding-left:12px;font-weight: 600;">My Sessions</p>
                                           
                    </td>
                    <td width="15%">
                        <p style="font-size: 14px;color: rgb(119, 119, 119);padding: 0;margin: 0;text-align: right;">
                            Today's Date
                        </p>
                        <p class="heading-sub12" style="padding: 0;margin: 0;">
                            <?php 

                        date_default_timezone_set('Asia/Kolkata');

                        $today = date('Y-m-d');
                        echo $today;

                        $list110 = $database->query("select  * from  schedule where docid=$userid;");

                        ?>
                        </p>
                    </td>
                    <td width="10%">
                        <button  class="btn-label"  style="display: flex;justify-content: center;align-items: center;"><img src="../img/calendar.svg" width="100%"></button>
                    </td>


                </tr>
               
                
                
                <tr>
                    <td colspan="4" style="padding-top:0px;width: 100%;" >
                        <center>
                        <table class="filter-container" border="0" >
                        <tr>
                           <td width="10%">

                           </td> 
                        

                    </tr>
                            </table>

                        </center>
                    </td>
                    
                </tr>
                
                <?php

                $sqlmain= "select schedule.scheduleid,schedule.title,doctor.docname,schedule.scheduledate,schedule.scheduletime,schedule.nop from schedule inner join doctor on schedule.docid=doctor.docid where doctor.docid=$userid ";
                    if($_POST){
                        //print_r($_POST);
                        $sqlpt1="";
                        if(!empty($_POST["sheduledate"])){
                            $sheduledate=$_POST["sheduledate"];
                            $sqlmain.=" and schedule.scheduledate='$sheduledate' ";
                        }

                    }

                ?>
                  
                <tr>
                </tr>
                       
                <td colspan="4" style="padding-top:0px;width: 100%;">
                    <center>
                        <form action="save_event.php" method="POST">
                        <div class="abc scroll">
                            <div id="calendar" style="max-width: 800px; margin: 20px auto; padding: 20px;"></div>
                        </div>
                        </form>
                    </center>
                </td>    
                        
            </table>
        </div>
    </div>
    <?php
    
    if($_GET){
        $id=$_GET["id"];
        $action=$_GET["action"];
        if($action=='drop'){
            $nameget=$_GET["name"];
            echo '
            <div id="popup1" class="overlay">
                    <div class="popup">
                    <center>
                        <h2>Are you sure?</h2>
                        <a class="close" href="schedule.php">&times;</a>
                        <div class="content">
                            You want to delete this record<br>('.substr($nameget,0,40).').
                            
                        </div>
                        <div style="display: flex;justify-content: center;">
                        <a href="delete-session.php?id='.$id.'" class="non-style-link"><button  class="btn-primary btn"  style="display: flex;justify-content: center;align-items: center;margin:10px;padding:10px;"<font class="tn-in-text">&nbsp;Yes&nbsp;</font></button></a>&nbsp;&nbsp;&nbsp;
                        <a href="schedule.php" class="non-style-link"><button  class="btn-primary btn"  style="display: flex;justify-content: center;align-items: center;margin:10px;padding:10px;"><font class="tn-in-text">&nbsp;&nbsp;No&nbsp;&nbsp;</font></button></a>

                        </div>
                    </center>
            </div>
            </div>
            '; 
        }elseif($action=='view'){
            $sqlmain= "select schedule.scheduleid,schedule.title,doctor.docname,schedule.scheduledate,schedule.scheduletime,schedule.nop from schedule inner join doctor on schedule.docid=doctor.docid  where  schedule.scheduleid=$id";
            $result= $database->query($sqlmain);
            $row=$result->fetch_assoc();
            $docname=$row["docname"];
            $scheduleid=$row["scheduleid"];
            $title=$row["title"];
            $scheduledate=$row["scheduledate"];
            $scheduletime=$row["scheduletime"];
            
           
            $nop=$row['nop'];


            $sqlmain12= "select * from appointment inner join patient on patient.pid=appointment.pid inner join schedule on schedule.scheduleid=appointment.scheduleid where schedule.scheduleid=$id;";
            $result12= $database->query($sqlmain12);
            echo '
            <div id="popup1" class="overlay">
                    <div class="popup" style="width: 70%;">
                    <center>
                        <h2></h2>
                        <a class="close" href="schedule.php">&times;</a>
                        <div class="content">
                            
                            
                        </div>
                        <div class="abc scroll" style="display: flex;justify-content: center;">
                        <table width="80%" class="sub-table scrolldown add-doc-form-container" border="0">
                        
                            <tr>
                                <td>
                                    <p style="padding: 0;margin: 0;text-align: left;font-size: 25px;font-weight: 500;">View Details.</p><br><br>
                                </td>
                            </tr>
                            
                            <tr>
                                
                                <td class="label-td" colspan="2">
                                    <label for="name" class="form-label">Session Title: </label>
                                </td>
                            </tr>
                            <tr>
                                <td class="label-td" colspan="2">
                                    '.$title.'<br><br>
                                </td>
                                
                            </tr>
                            <tr>
                                <td class="label-td" colspan="2">
                                    <label for="Email" class="form-label">Doctor of this session: </label>
                                </td>
                            </tr>
                            <tr>
                                <td class="label-td" colspan="2">
                                '.$docname.'<br><br>
                                </td>
                            </tr>
                            <tr>
                                <td class="label-td" colspan="2">
                                    <label for="nic" class="form-label">Scheduled Date: </label>
                                </td>
                            </tr>
                            <tr>
                                <td class="label-td" colspan="2">
                                '.$scheduledate.'<br><br>
                                </td>
                            </tr>
                            <tr>
                                <td class="label-td" colspan="2">
                                    <label for="Tele" class="form-label">Scheduled Time: </label>
                                </td>
                            </tr>
                            <tr>
                                <td class="label-td" colspan="2">
                                '.$scheduletime.'<br><br>
                                </td>
                            </tr>
                            <tr>
                                <td class="label-td" colspan="2">
                                    <label for="spec" class="form-label"><b>Patients that Already registerd for this session:</b> ('.$result12->num_rows."/".$nop.')</label>
                                    <br><br>
                                </td>
                            </tr>

                            
                            <tr>
                            <td colspan="4">
                                <center>
                                 <div class="abc scroll">
                                 <table width="100%" class="sub-table scrolldown" border="0">
                                 <thead>
                                 <tr>   
                                        <th class="table-headin">
                                             Patient ID
                                         </th>
                                         <th class="table-headin">
                                             Patient name
                                         </th>
                                         <th class="table-headin">
                                             
                                             Appointment number
                                             
                                         </th>
                                        
                                         
                                         <th class="table-headin">
                                             Patient Telephone
                                         </th>
                                         
                                 </thead>
                                 <tbody>';
                                 
                
                
                                         
                                         $result= $database->query($sqlmain12);
                
                                         if($result->num_rows==0){
                                             echo '<tr>
                                             <td colspan="7">
                                             <br><br><br><br>
                                             <center>
                                             <img src="../img/notfound.svg" width="25%">
                                             
                                             <br>
                                             <p class="heading-main12" style="margin-left: 45px;font-size:20px;color:rgb(49, 49, 49)">We  couldnt find anything related to your keywords !</p>
                                             <a class="non-style-link" href="appointment.php"><button  class="login-btn btn-primary-soft btn"  style="display: flex;justify-content: center;align-items: center;margin-left:20px;">&nbsp; Show all Appointments &nbsp;</font></button>
                                             </a>
                                             </center>
                                             <br><br><br><br>
                                             </td>
                                             </tr>';
                                             
                                         }
                                         else{
                                         for ( $x=0; $x<$result->num_rows;$x++){
                                             $row=$result->fetch_assoc();
                                             $apponum=$row["apponum"];
                                             $pid=$row["pid"];
                                             $pname=$row["pname"];
                                             $ptel=$row["ptel"];
                                             
                                             echo '<tr style="text-align:center;">
                                                <td>
                                                '.substr($pid,0,15).'
                                                </td>
                                                 <td style="font-weight:600;padding:25px">'.
                                                 
                                                 substr($pname,0,25)
                                                 .'</td >
                                                 <td style="text-align:center;font-size:23px;font-weight:500; color: var(--btnnicetext);">
                                                 '.$apponum.'
                                                 
                                                 </td>
                                                 <td>
                                                 '.substr($ptel,0,25).'
                                                 </td>
                                                 
                                                 
                
                                                 
                                             </tr>';
                                             
                                         }
                                     }
                                          
                                     
                
                                    echo '</tbody>
                
                                 </table>
                                 </div>
                                 </center>
                            </td> 
                         </tr>

                        </table>
                        </div>
                    </center>
                    <br><br>
            </div>
            </div>
            ';  
    }
}

    ?>
    </div>
    <script>
document.addEventListener('DOMContentLoaded', function() {
    var calendarEl = document.getElementById('calendar');

    // Prepare the events data from PHP
    var eventsData = <?php echo json_encode($appointments); ?>; // Ensure appointments are properly fetched
    console.log('Events Data:', eventsData); // Debugging line to check fetched data

    var calendar = new FullCalendar.Calendar(calendarEl, {
        initialView: 'dayGridMonth',
        selectable: true,   // Enable date selection
        editable: true,     // Allow events to be edited (drag/drop)
        events: eventsData, // Load events from PHP

        // Event click handler
        eventClick: function(info) {
            console.log("Event clicked: ", info.event);  // Log clicked event details

            var newTitle = prompt('Edit Event Title:', info.event.title);
            if (newTitle) {
                // Send AJAX request to update the event in the database
                $.ajax({
                    url: 'update_event.php',
                    method: 'POST',
                    data: { id: info.event.id, title: newTitle },
                    success: function(response) {
                        console.log("Update response: ", response);  // Log response from server
                        
                        if (response.status === 'success') {
                            info.event.setProp('title', newTitle);  // Update the title in the calendar
                        } else {
                            alert('Error updating event: ' + response.message);
                        }
                    },
                    error: function(jqXHR, textStatus, errorThrown) {
                        console.error('AJAX error:', textStatus, errorThrown);  // Log AJAX errors
                        alert('AJAX error: ' + textStatus + ', ' + errorThrown);
                    }
                });
            }
        },

        // Date selection handler for creating new events
        select: function(info) {
            console.log("Date selected: ", info.startStr);  // Log selected date

            var title = prompt('Enter Event Title:');
            if (title) {
                console.log("Creating new event with title: ", title);  // Log new event title
                
                // Send AJAX request to save the new event in the database
                $.ajax({
                    url: 'save_event.php',
                    method: 'POST',
                    data: {
                        title: title,
                        start: info.startStr,
                        end: info.endStr // Include end date if needed
                    },
                    success: function(response) {
                        console.log("Save response: ", response);  // Log response from server

                        if (response.status === 'success') {
                            calendar.addEvent({
                                id: response.id,   // Use the ID from the response
                                title: title,
                                start: info.startStr,
                                end: info.endStr,
                                allDay: true
                            });
                        } else {
                            alert('SUCCESSFULLY ADDED!');
                        }
                    },
                    error: function(jqXHR, textStatus, errorThrown) {
                        console.error('AJAX error:', textStatus, errorThrown);  // Log AJAX errors
                        alert('AJAX error: ' + textStatus + ', ' + errorThrown);
                    }
                });
            }

            calendar.unselect(); // Clear the selection
        }
    });

    calendar.render(); // Render the calendar
});
</script>
</body>
</html>