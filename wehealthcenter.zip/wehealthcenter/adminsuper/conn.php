<?php

$conn = mysqli_connect('localhost','root','','dbkupal') or die('connection failed');

?>