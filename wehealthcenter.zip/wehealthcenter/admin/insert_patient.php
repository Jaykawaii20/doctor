<?php
// insert_patient.php

// Database connection
$host = "localhost";
$username = "root"; // change as per your DB setup
$password = ""; // change as per your DB setup
$dbname = "dbkupal"; // change to your actual database name

$conn = new mysqli($host, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve form data
    $patient_name = $_POST['patient_name'];
    $middlename = $_POST['middlename'];
    $lastname = $_POST['lastname'];
    $birthdate = $_POST['birthdate'];
    $address = $_POST['address'];
    $age = $_POST['age'];
    $civil_status = $_POST['civil_status'];
    $gender = $_POST['gender'];
    $bp = $_POST['bp'];
    $temp = $_POST['temp'];
    $weight = $_POST['weight'];
    $height = $_POST['height'];
    $session_category = $_POST['session_category'];

    // Insert data into the database
    $sql = "INSERT INTO patient_walkin (name, middlename, lastname, birthdate, address, age, civil_status, gender, bp, temp, weight, height, session_category)
            VALUES ('$patient_name', '$middlename', '$lastname', '$birthdate', '$address', $age, '$civil_status', '$gender', '$bp', '$temp', '$weight', '$height','$session_category')";

    if ($conn->query($sql) === TRUE) {
        echo "New patient added successfully!";
        header("Location: patient.php?success=1"); // Redirect to patient page with success
        exit();
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Close the connection
$conn->close();
?>
